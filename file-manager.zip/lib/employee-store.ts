import type { Employee, EmployeeFormData } from "@/types/employee"

// In-memory storage for demo purposes
const employees: Employee[] = [
  {
    id: "1",
    firstName: "John",
    lastName: "Doe",
    email: "john.doe@company.com",
    position: "Software Engineer",
    department: "Engineering",
    salary: 75000,
    hireDate: "2023-01-15",
    status: "active",
  },
  {
    id: "2",
    firstName: "Jane",
    lastName: "Smith",
    email: "jane.smith@company.com",
    position: "Product Manager",
    department: "Product",
    salary: 85000,
    hireDate: "2022-11-20",
    status: "active",
  },
  {
    id: "3",
    firstName: "Mike",
    lastName: "Johnson",
    email: "mike.johnson@company.com",
    position: "Designer",
    department: "Design",
    salary: 65000,
    hireDate: "2023-03-10",
    status: "inactive",
  },
]

export function getAllEmployees(): Employee[] {
  return employees
}

export function getEmployeeById(id: string): Employee | undefined {
  return employees.find((emp) => emp.id === id)
}

export function createEmployee(data: EmployeeFormData): Employee {
  const newEmployee: Employee = {
    id: Date.now().toString(),
    ...data,
  }
  employees.push(newEmployee)
  return newEmployee
}

export function updateEmployee(id: string, data: Partial<EmployeeFormData>): Employee | null {
  const index = employees.findIndex((emp) => emp.id === id)
  if (index === -1) return null

  employees[index] = { ...employees[index], ...data }
  return employees[index]
}

export function deleteEmployee(id: string): boolean {
  const index = employees.findIndex((emp) => emp.id === id)
  if (index === -1) return false

  employees.splice(index, 1)
  return true
}

export function searchEmployees(query: string): Employee[] {
  const lowercaseQuery = query.toLowerCase()
  return employees.filter(
    (emp) =>
      emp.firstName.toLowerCase().includes(lowercaseQuery) ||
      emp.lastName.toLowerCase().includes(lowercaseQuery) ||
      emp.email.toLowerCase().includes(lowercaseQuery) ||
      emp.position.toLowerCase().includes(lowercaseQuery) ||
      emp.department.toLowerCase().includes(lowercaseQuery),
  )
}
