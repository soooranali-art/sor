export interface Employee {
  id: string
  firstName: string
  lastName: string
  email: string
  position: string
  department: string
  salary: number
  hireDate: string
  status: "active" | "inactive"
}

export interface EmployeeFormData {
  firstName: string
  lastName: string
  email: string
  position: string
  department: string
  salary: number
  hireDate: string
  status: "active" | "inactive"
}
