"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { EmployeeForm } from "@/components/employee-form"
import { EmployeeTable } from "@/components/employee-table"
import type { Employee, EmployeeFormData } from "@/types/employee"
import { getAllEmployees, createEmployee, updateEmployee, deleteEmployee, searchEmployees } from "@/lib/employee-store"
import { useState, useEffect } from "react"
import { Plus, Search, Users } from "lucide-react"

export default function EmployeeDatabase() {
  const [employees, setEmployees] = useState<Employee[]>([])
  const [filteredEmployees, setFilteredEmployees] = useState<Employee[]>([])
  const [showForm, setShowForm] = useState(false)
  const [editingEmployee, setEditingEmployee] = useState<Employee | undefined>()
  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    const allEmployees = getAllEmployees()
    setEmployees(allEmployees)
    setFilteredEmployees(allEmployees)
  }, [])

  useEffect(() => {
    if (searchQuery.trim() === "") {
      setFilteredEmployees(employees)
    } else {
      const results = searchEmployees(searchQuery)
      setFilteredEmployees(results)
    }
  }, [searchQuery, employees])

  const handleAddEmployee = (data: EmployeeFormData) => {
    const newEmployee = createEmployee(data)
    const updatedEmployees = getAllEmployees()
    setEmployees(updatedEmployees)
    setShowForm(false)
  }

  const handleEditEmployee = (data: EmployeeFormData) => {
    if (editingEmployee) {
      updateEmployee(editingEmployee.id, data)
      const updatedEmployees = getAllEmployees()
      setEmployees(updatedEmployees)
      setEditingEmployee(undefined)
      setShowForm(false)
    }
  }

  const handleDeleteEmployee = (id: string) => {
    if (confirm("Are you sure you want to delete this employee?")) {
      deleteEmployee(id)
      const updatedEmployees = getAllEmployees()
      setEmployees(updatedEmployees)
    }
  }

  const handleEdit = (employee: Employee) => {
    setEditingEmployee(employee)
    setShowForm(true)
  }

  const handleCancel = () => {
    setShowForm(false)
    setEditingEmployee(undefined)
  }

  const activeEmployees = employees.filter((emp) => emp.status === "active").length
  const totalEmployees = employees.length

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Employee Database</h1>
          <p className="text-gray-600">Manage your company's employee records</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Employees</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalEmployees}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Employees</CardTitle>
              <Users className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{activeEmployees}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Inactive Employees</CardTitle>
              <Users className="h-4 w-4 text-red-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{totalEmployees - activeEmployees}</div>
            </CardContent>
          </Card>
        </div>

        {showForm ? (
          <div className="mb-8 flex justify-center">
            <EmployeeForm
              employee={editingEmployee}
              onSubmit={editingEmployee ? handleEditEmployee : handleAddEmployee}
              onCancel={handleCancel}
            />
          </div>
        ) : (
          <Card className="mb-8">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Employee List</CardTitle>
                <Button onClick={() => setShowForm(true)} className="gap-2">
                  <Plus className="h-4 w-4" />
                  Add Employee
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <div className="relative max-w-sm">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                  <Input
                    type="search"
                    placeholder="Search employees..."
                    className="pl-9"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>

              {filteredEmployees.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  {searchQuery
                    ? "No employees found matching your search."
                    : "No employees found. Add your first employee!"}
                </div>
              ) : (
                <EmployeeTable employees={filteredEmployees} onEdit={handleEdit} onDelete={handleDeleteEmployee} />
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
